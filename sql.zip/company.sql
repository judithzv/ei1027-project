CREATE TABLE Company (
name		VARCHAR(50),
CIF		VARCHAR(50),
contactPerson	VARCHAR(50),
telephoneNumber	VARCHAR(50),
userName	VARCHAR(50),
password	VARCHAR(50),

CONSTRAINT cp_company PRIMARY KEY (CIF)
); 

CREATE TABLE Request (
number		VARCHAR(50),
state		VARCHAR(50) DEFAULT 'in process',
service		VARCHAR(50),
schedule	VARCHAR(50),
DNI		VARCHAR(50),
idContract	VARCHAR(50) NULL,

CONSTRAINT cp_request PRIMARY KEY (number),
CONSTRAINT ca_request_elderly FOREIGN KEY(DNI) REFERENCES Elderly(DNI) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT ca_request_contract FOREIGN KEY(idContract) REFERENCES Contract(id) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT request_service CHECK(service='catering' OR service='cleanning' OR service='health'),
CONSTRAINT request_state CHECK(state='accepted' OR state='rejected' OR state='in process')
);
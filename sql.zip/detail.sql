CREATE TABLE Detail (
concept		VARCHAR(50),
amount		FLOAT,
invoiceCode	VARCHAR(50),
requestCode	VARCHAR(50),

CONSTRAINT cp_detail PRIMARY KEY (concept, amount, code),
CONSTRAINT ca_detail_invoice FOREIGN KEY(invoiceCode) REFERENCES Invoice(code) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT ca_detail_request FOREIGN KEY(requestCode) REFERENCES Request(number) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT detail_amount CHECK(amount>0)
); 

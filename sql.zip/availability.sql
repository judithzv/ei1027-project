CREATE TABLE Availability (
data		DATE,
startTime	TIME,
endTime		TIME,
DNI_elderly	VARCHAR(50) NULL,
DNI_volunteer	VARCHAR(50),

CONSTRAINT cp_availability PRIMARY KEY (data, startTime, endTime, DNI_volunteer),
CONSTRAINT ca_availability_elderly FOREIGN KEY(DNI_elderly) REFERENCES Elderly(DNI) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT ca_availability_volunteer FOREIGN KEY(DNI_volunteer) REFERENCES Volunteer(DNI) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT start_end CHECK(startTime<=endTime)
); 

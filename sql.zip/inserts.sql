INSERT INTO elderly VALUES ('Miguel', 'Hernandez Perez', 'miguel1949', 'miguelitohp49', 659232474, 'miguel1949@gmail.com', '1949-06-28', NULL, '46412589L', 'Hipertensión', NULL, NULL);
INSERT INTO elderly VALUES ('María Dolores', 'Sanz Peris', 'mdolosp', 'dolo42sp', 689455214, 'mdolores42@gmail.com', '1942-01-17', NULL, '32569874M', 'Alzheimer', '33%', NULL);
INSERT INTO elderly VALUES ('Maruja', 'García Solano', 'marugarso', 'marujita.50', 733586945, 'marujitags@gmail.com', '1950-11-03', NULL, '23655894N', NULL, NULL);

               ^
INSERT INTO address VALUES('Calle Valve, 7º9', '2421472', 'Valencia', 'España', '23655894N');
INSERT INTO address VALUES('Calle Juan Ramón Gimenez, 24', '124329', 'Burgos', 'España', '46412589L');
INSERT INTO address VALUES('Plaza Tetuan 7, 8ºD', '73643', 'La Rioja', 'España', '32569874M');


INSERT INTO bankdata VALUES('38438','Santander','Manila','23655894N');
INSERT INTO bankdata VALUES('435324','Bankia','Presa','46412589L');
INSERT INTO bankdata VALUES('214312','Bankinter','Mayor','32569874M');
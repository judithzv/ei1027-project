CREATE TABLE Invoice (
code		VARCHAR(50),
startDate	DATE,
endDate		DATE,
amount		FLOAT,
DNI		VARCHAR(50),

CONSTRAINT cp_invoice PRIMARY KEY (code),
CONSTRAINT ca_invoice_elderly FOREIGN KEY(DNI) REFERENCES Elderly(DNI) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT invoice_amount CHECK(amount>0)
); 

CREATE TABLE Volunteer (
name		VARCHAR(50),
surNames	VARCHAR(50),
userName	VARCHAR(50),
password	VARCHAR(50),
telephoneNumber	INTEGER,
mail		VARCHAR(50),
birthDate	DATE,
hobbies		VARCHAR(100) NULL,
DNI		VARCHAR(50),

CONSTRAINT cp_volunteer PRIMARY KEY (DNI)
); 

CREATE TABLE Contract (
id		VARCHAR(50),
startDate	DATE,
endDate		DATE,
serviceType	VARCHAR(50),
price		FLOAT,
signatureDate	DATE,
CIF		VARCHAR(50),

CONSTRAINT cp_contract PRIMARY KEY (id),
CONSTRAINT ca_contract_company FOREIGN KEY(CIF) REFERENCES Company(CIF) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT contract_service CHECK(serviceType='catering' OR serviceType='cleanning' OR serviceType='health'),
CONSTRAINT contract_price CHECK(price>0)
); 

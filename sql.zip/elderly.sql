CREATE TABLE Elderly (
name		VARCHAR(50),
surNames	VARCHAR(50),
userName	VARCHAR(50),
password	VARCHAR(50),
telephoneNumber	INTEGER,
mail		VARCHAR(50),
birthDate	DATE,
hobbies		VARCHAR(100) NULL,
DNI		VARCHAR(50),
illnesses	VARCHAR(100) NULL,
disability	VARCHAR(50) NULL,
socialWorker	VARCHAR(50) NULL,

CONSTRAINT cp_elderly PRIMARY KEY (DNI)
); 
